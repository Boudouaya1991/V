Dear MySQL users,

MySQL Connector/Python 8.0.27 is the latest GA release version of the
MySQL Connector Python 8.0 series. The X DevAPI enables application
developers to write code that combines the strengths of the relational
and document models using a modern, NoSQL-like syntax that does not
assume previous experience writing traditional SQL.

To learn more about how to write applications using the X DevAPI, see

  http://dev.mysql.com/doc/x-devapi-userguide/en/

For more information about how the X DevAPI is implemented in MySQL
Connector/Python, and its usage, see

  http://dev.mysql.com/doc/dev/connector-python

Please note that the X DevAPI requires at least MySQL Server version 8.0
or higher with the X Plugin enabled. For general documentation about how
to get started using MySQL as a document store, see

  http://dev.mysql.com/doc/refman/8.0/en/document-store.html

To download MySQL Connector/Python 8.0.27, see the "General Availability
(GA) Releases" tab at

  http://dev.mysql.com/downloads/connector/python/


Changes in MySQL Connector/Python 8.0.27 (2021-10-19, General Availability)

Functionality Added or Changed

     * In Connector/Python 8.0.26, the capability was introduced
       for applications that use the classic MySQL connections
       for accounts that use the authentication_kerberos
       server-side authentication plugin, provided that the
       correct Kerberos tickets are available or can be obtained
       from Kerberos. That capability was available on client
       hosts running Linux only. It is now available on client
       hosts running Windows.

       For more information about Kerberos authentication, see
       Kerberos Pluggable Authentication
       (https://dev.mysql.com/doc/refman/8.0/en/kerberos-pluggable-authentication.html).

     * Added wheel packages for the commercial edition.

     * Improved the DMG package as previously it assumed that
       XCode was installed to provide the Python installation.
       Additionally, there are now two separate DMG files; one
       for x86-64 and another for ARM. These installers now
       provides an option to choose which Python version to use,
       and defaults to the version provided by XCode.

     * Added a new converter_str_fallback connection option that
       allows enabling the conversion to str of value types not
       supported by the Connector/Python converter class, or by
       a custom converter class. It defaults to False.

Bugs Fixed

     * Using the C-extension, attempting to connect with chained
       SSL certificates using ssl_verify_identity=True did not
       function. The workaround was to use the pure Python
       implementation. (Bug #33177337)

     * Printing an mysqlx.result.row object output the generic
       representation of a class in Python rather than the
       string value. (Bug #28641350)


Enjoy and thanks for the support!

On Behalf of the MySQL Engineering Team,
Kent Boortz
