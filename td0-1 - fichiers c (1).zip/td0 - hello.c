/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Les en-têtes (headers)
// les directives de pré-processeur qui débutent par un # et ne finissent pas un ; car ce n'est pas du code
// la directive include permet d'inclure des bibliothèques dans le code C inlcude <nom_library>
// bibliothèques classiques : maths, time, stdio (STandarD Input Output), stdlib (STandarD LIBrary), query
// toutes les bibliothqèues finissent par .h

#include <stdio.h>



// point d'entrée du programme
int main()
{
    // Commentaires sur une ligne sont précédés par un double slash
    /* les commentaires sur plusieurs lignes sont
    entre /* et */ 
    // printf() -> sortie issue de stdio
    printf("Hello World !");
    
    // convention en  C : le main retourne 0 si tout est OK.
    return 0;
}
