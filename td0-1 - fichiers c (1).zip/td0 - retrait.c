#include <stdio.h>
// TP 0 - Question 2

// Les directives de pré-processeur

#include <stdio.h>
#include <stdlib.h>

//la fonction d'entrée du programme

int main()
{
// définition des variables
int solde_compte = 800;
int montant_retrait = 0;

// les instructions

printf("Votre compte a un solde de %d euros \n", solde_compte);
printf("Combien d'argent voulez vous retirer ? (montant entier) \n");
scanf("%d",&montant_retrait);
// calcul du solde
solde_compte = solde_compte - montant_retrait;
// afffichage du solde
printf("Votre compte a désormais un solde de %d euros \n", solde_compte);

//fin du programme. Retourne 0 si tout est ok, une autre valeur sinon
return 0;
}







