/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    // question 3 du td0
    // déclaration des variables
    int pxPoulet = 10;
    int pxPotatoes = 2;
    int pxLegumes = 7;
    double pxGlace = 4.5;
    int choix = 0;
    double addition = 0;
    int devise = 1; // par défaut le montant est en € d'où le 1 (2 pour le dollar)

// Affichage du menu proposé
printf("Que voulez-vous manger ? \n");
printf("1 -> du Poulet à %d euros \n", pxPoulet);
printf("2 -> des Potatoes \n");
printf("3 -> des Légumes \n");
printf("4 -> de la Glace \n");
scanf("%d", &choix);

// selon le choix fait, on va calculer le montant ) payer. Instruction selon/faire -> switch case
// Le switch(variable choix) déclenche le bloc conditionnel
/*switch(var_choix){
    // chaque cas est sous la forme case valeur: actions; break;
    case valeur1:
    actions1;
    actions2;
    break;
    case valeur2:
    actions1;
    break;
    case par défaut: (optionnel)
    actions;
    break;
}*/

switch(choix){
    case 1:
    addition = addition + pxPoulet;
    break;
    case 2:
    addition = addition + pxPotatoes;
    break;
    case 3:
    addition = addition + pxLegumes;
    break;
    case 4:
    addition = addition + pxGlace;
    break;
    default:  //Le cas par défault, avec le paramètres default:
    printf("Votre choix n'existe pas...\n");
    break;
}

// Choix de la devise de paiement entre le dollar et l'euro
printf("En quelle devise voulez-vous payer ?\n");
printf("En euros (1) ou en dollars (2) \n");
// on va supposer que les prix initiaux sont en euros
// le taux de change est de 1.21$ pour 1 €
scanf("%d", &devise);
// test de la devise choisie par un if / else

// retourne 0 si tout est OK
    return 0;
}







