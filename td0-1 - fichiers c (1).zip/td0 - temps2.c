// Les directives du pré-processeur 
#include <stdio.h>

// Les fonctions et procédures utilisées dans le main()
//type nom_fonction(paramètres){instructions}. le type depend de la valeur du return
// pour les procédures, le type est de type vide car il n'y a pas de return -> void
// Le code des procédures et des fonctions se situe après le main()
// Le prototypage est utilisé : on indique jsute la ligne d'appel des fonctions et des procédures
void conversion(int *a,int *b);

// Version C Alternative - Tout pointeurs
// Le point d'entrée du programme
int main()
{
// définition des variables 
int h,m;
int *heures=&h;
int *minutes=&m;
//int valeur_saisie =0;
// Les instructions de saisie des données
printf("Saisir le nombre total de minutes \n");
scanf("%d", minutes);
// Appel de la procédure 
conversion(heures,minutes);
// Affichage du résultat
printf("Le résultat est de %d heures et %d minutes \n", *heures, *minutes);
    // Renvoie 0 si tout est OK
    return 0;
}



// Le contenu des procédures et des fonctions après le main()
void conversion(int *a,int *b){
   *a = *b / 60;
*b = *b % 60; // % est le sympbole du modulo
}
