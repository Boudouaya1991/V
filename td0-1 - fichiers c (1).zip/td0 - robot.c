/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
// déclaration des variables
int marche_actuelle =0;
int compteur=0;

// Affichage de la position du robot
// marche_actuelle = marche_actuelle +1 ;
// Ecriture simplifiée pour l'incrémentation et la décrémentation de une unité : variable++ (variable = variable +1) ou variable-- (variable = variable - 1)
// tant que (booléenne) faire {instructions} -> while

while(marche_actuelle < 60){
marche_actuelle++;
printf("Le robot se trouve sur la marche numéro %d \n",marche_actuelle);
}

// faire {instructions} jusqu'à (booléenne) -> do {instructions} while(booléenne)
do{
    marche_actuelle++;
printf("Le robot se trouve sur la marche numéro %d \n",marche_actuelle);
}
while(marche_actuelle < 60);

// pour un nombre de fois déterminé faire
// variable de comptage (compteur) + for(valeur initiale compteur; valeur finale compteur conditionnelle; pas du compteur){instructions}
for(compteur = 0; compteur <= 59; compteur++){
        marche_actuelle++;
printf("Le robot se trouve sur la marche numéro %d \n",marche_actuelle);
    
}
// équivalent Python
/*for compteur in range(60):
    marche_actuelle+=1
    print(f"Le robot se trouve sur la marche numéro {marche_actuelle}")
*/

// fin du programme 
printf("Le robot est arrivé !!! \n");

    return 0;
}
